# Handoff: WhiskyAdvisor Design Improvements

## Overview
Seven design improvements to the WhiskyAdvisor Next.js app, covering navigation, data visualisation, typography, component richness, and a new toast system. All changes were designed against the live codebase at `erwee-burger/WhiskyAdvisor@main`.

## About the Design Files
The files in this bundle are **production-ready source files** — not prototypes. They are modified versions of the actual files from the repo, ready to drop in. Each file has been edited with minimal diff from the original; no new dependencies are introduced.

## Fidelity
**High-fidelity.** All changes match the existing design token system exactly, using the same CSS variables, class naming conventions, border-radius tokens, and animation patterns already present in the codebase.

---

## Files to Copy

| Source file (this bundle) | Destination in repo |
|---|---|
| components/top-nav.tsx | components/top-nav.tsx |
| components/stat-card.tsx | components/stat-card.tsx |
| components/advisor-card.tsx | components/advisor-card.tsx |
| components/collection-browser.tsx | components/collection-browser.tsx |
| components/toast.tsx | components/toast.tsx (NEW) |
| app/design-improvements.css | app/design-improvements.css (NEW) |
| app/layout.tsx | app/layout.tsx |

---

## Change 1 — top-nav.tsx: Inline desktop nav

Five primary routes render inline inside the pill nav bar at screens >= 900px.
The hamburger menu remains for mobile and less-used pages.

New constant DESKTOP_PRIMARY at top of file controls which hrefs appear inline.

New CSS classes (in design-improvements.css):
  .top-nav-desktop-links   — flex container, hidden by default, shown at >=900px
  .top-nav-desktop-link    — individual link pill
  .top-nav-desktop-link-active — active state matching existing menu-link-active gradient

---

## Change 2 — stat-card.tsx: Trend + sparkline

Three new optional props:
  trend?: string           e.g. "up 4 this month"
  trendDir?: "up" | "down" | "neutral"
  history?: number[]       oldest to newest, used to render sparkline bars

Backwards compatible — existing usages with only label/value/hint are unchanged.

Wiring required in lib/repository.ts: pass trend and history from getDashboardData().
At minimum a trend string is enough; history needs an array of 6-8 monthly counts.

Example:
  <StatCard
    label="Owned"
    value="42"
    trend="up 4 this month"
    trendDir="up"
    history={[28, 30, 32, 34, 36, 38, 42]}
  />

New CSS classes:
  .stat-card-top             flex row: label + sparkline
  .stat-sparkline            sparkline bar container
  .stat-sparkline-bar        individual bar (4px wide, variable height %)
  .stat-sparkline-bar-hi     last bar highlighted in brighter amber
  .stat-trend                trend text below value
  .stat-trend-up/down/neutral  colour modifiers

---

## Change 3 — advisor-card.tsx: Score bar + rationale

- Score shown as a progress bar instead of plain text
- suggestion.rationale rendered as italic paragraph (field existed in type, just unstyled)
- Supporting tags use new .pill-flavour class

New CSS classes:
  .advisor-card-head         flex: copy block + Open button
  .advisor-card-copy         grid: title + score row
  .advisor-score-row         flex: bar + label
  .advisor-score-bar / .advisor-score-fill  progress bar
  .advisor-score-label       "X/100" text in accent colour
  .advisor-card-rationale    italic muted paragraph

---

## Change 4 — collection-browser.tsx: Lighting mode toggle

New state: lighting persisted to localStorage under key "collection-lighting"
Values: "bar-glow" | "candlelight" | "daylight"

The section root gets class shelf-room-{mode} appended.
The old pill-row hints in .shelf-caption are replaced by the lighting toggle.

New CSS classes:
  .shelf-room-candlelight    warmer amber/orange background + shelf rail tint
  .shelf-room-daylight       cooler blue-grey background + shelf rail tint
  .shelf-lighting-toggle     pill-shaped button group container
  .shelf-lighting-btn        individual mode button
  .shelf-lighting-btn-active active mode (amber gradient)

---

## Change 5 — components/toast.tsx (NEW FILE)

Complete toast notification system.

Exports:
  <ToastProvider>   — wraps the app, renders toast region
  useToast()        — hook returning { showToast(message, variant) }
  ToastVariant      — "success" | "error" | "info"

Usage anywhere in the app:
  import { useToast } from "@/components/toast";
  const { showToast } = useToast();
  showToast("Bottle added", "success");
  showToast("Something went wrong", "error");

Toasts auto-dismiss after 3.5s. Users can click x to dismiss early.

New CSS classes:
  .toast-region              fixed bottom-right container
  .toast                     individual toast pill
  .toast-success/error/info  border colour variants
  .toast-dot + modifiers     coloured status dot
  .toast-close               dismiss button
  @keyframes toast-in        entry animation

---

## Change 6 — app/design-improvements.css (NEW FILE)

Import AFTER globals.css in layout.tsx:
  import "@/app/design-improvements.css";

Contains all CSS for changes 1-5, plus:

### Dual typeface system
  --font-display: "Cormorant Garamond"  headings, large numerics, brand
  --font-ui: "Inter"                    labels, chips, metadata, buttons, forms
  Inter loaded via @import from Google Fonts at top of file.

### Pill colour semantics — six new modifier classes

  .pill-flavour        tasting notes       warm amber (default look)
  .pill-region         country / region    cool slate-blue
  .pill-status-open    fill state open     soft green
  .pill-status-sealed  fill state sealed   warm amber tint
  .pill-status-finished fill state done    muted neutral
  .pill-limited        limited release     deep crimson
  .pill-indie          independent bottler soft purple

---

## Change 7 — app/layout.tsx

Two additions only:

  import "@/app/design-improvements.css";   // after globals.css
  import { ToastProvider } from "@/components/toast";

  Wrap existing children:
    <NavigationFeedbackProvider>
      <ToastProvider>          // ADD
        <div className="app-shell">...</div>
      </ToastProvider>         // ADD
    </NavigationFeedbackProvider>

---

## Pill Classes — Where to Apply Them

The new modifier classes need wiring in existing components:

  components/collection-card.tsx
    highlightTags map: detect fill state → .pill-status-open / sealed / finished
    region tag → .pill-region
    limited flag → .pill-limited
    isIndependentBottler → .pill-indie

  components/advisor-card.tsx    already uses .pill-flavour (done)

  components/bottle-record-editor.tsx  tag pills in detail view
  components/tastings-hub.tsx          bottle tag pills in session cards

---

## No New Dependencies

All changes use only existing Next.js, React, and CSS.
Inter is loaded from Google Fonts via @import in design-improvements.css.
